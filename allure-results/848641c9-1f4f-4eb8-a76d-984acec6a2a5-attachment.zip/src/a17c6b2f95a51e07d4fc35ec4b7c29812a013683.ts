import { test as baseTest, expect, Page } from '@playwright/test';
import { POManager } from '../pages/POManager';
import { ENV } from '../config/environment';



type PageFixtures = {
  pom: POManager;
};

export const test = baseTest.extend<PageFixtures>({
    pom: async({page}, use)=>{
        const pom = new POManager(page);
        await use(pom);
    },

    page: async({page}, use)=>{
        await page.addLocatorHandler(
    page.getByRole('heading', { name: 'We value your privacy' }),
    async () => {
      await page.getByRole('button', { name: 'Close' }).click();
    }
  );
     await use(page);
    },

});




export { expect } from '@playwright/test';
export { Page } from '@playwright/test';