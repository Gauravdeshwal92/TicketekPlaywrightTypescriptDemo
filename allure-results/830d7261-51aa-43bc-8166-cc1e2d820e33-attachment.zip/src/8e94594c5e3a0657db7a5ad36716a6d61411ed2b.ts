
import type {Page, Locator} from '@playwright/test'
import { TIMEOUT } from 'node:dns';

export class ShowPage{

    cookieCloseButton: Locator;
    venueName: Locator;
    showTitle_txt: Locator;
    findTickets_btn: Locator;
    performanceDate:Locator
    selectDate:Locator
    buyButtonSpinner:Locator

    constructor(page:Page){
        this.cookieCloseButton = page.getByRole('button', { name: 'Close' });
        this.venueName = page.locator('span.plainText');
        this.showTitle_txt = page.locator('h1.sectionHeading');
        this.findTickets_btn = page.locator('input.btn')
        this.performanceDate=page.getByRole('combobox')
        this.selectDate=page.locator('option')
        this.buyButtonSpinner = page.locator('#buyButton-three-dots');
    }

     async getShowTitle():Promise<String>{

        const showTitle = await this.showTitle_txt.innerText();
        return showTitle ? showTitle.replace(/\s+/g,' ').trim() :''
    }


    async getVenueSelected():Promise<string>{

        const venueName = await this.venueName.innerText();
        return venueName ? venueName.trim() :''
    }

    async selectShowDate(date:string){

        //await this.performanceDate.click()
        await this.performanceDate.selectOption({ label: date });
       // this.buyButtonSpinner.waitFor({state:'hidden', timeout:10000}).catch(()=>{});
    }

    async getShowDateSelected(){

        return await this.performanceDate.innerText()
    }

    async clickOnFindTickets(){
        await this.findTickets_btn.waitFor({ state: 'visible', timeout: 15000 })
        await this.findTickets_btn.click();
    }
}