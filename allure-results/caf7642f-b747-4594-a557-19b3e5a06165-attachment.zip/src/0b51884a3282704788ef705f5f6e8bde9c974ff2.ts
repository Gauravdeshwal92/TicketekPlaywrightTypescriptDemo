import {Locator, Page} from '@playwright/test'


export class SelectTicketCategories{

    page:Page
    chooseYourTickets_txt:Locator
    selectCategory:Locator
    priceCategory:Locator
    next_btn:Locator
    


    constructor(page:Page){
        this.page=page;
        this.selectCategory = page.locator('li')
        this.priceCategory = page.locator('.selectTktBlock:not(.ng-hide)')
        this.chooseYourTickets_txt = page.getByRole('heading',{'name':'Choose your tickets'})
        this.next_btn = page.getByRole('button', { name: 'Next' })


    }


    async selectTicketCategory(categoryName :string){
       const ticketCategory = this.selectCategory.filter({hasText:categoryName})
       ticketCategory.getByRole('button',{'name':'Select'}).click()
    }

    async selectTicketQuantity(priceType:string,noOfTickets:number){
            const ticketQuantity = await this.priceCategory.filter({hasText:priceType}).first()
             for (let i = 0; i < noOfTickets; i++) {
                await ticketQuantity.locator('button.increment').first().click();
             }
    }

    async chooseInAppDeliveryOption(deliveryOption:string){

       if( !await this.page.getByText(deliveryOption, { exact: true }).isChecked()){
            await this.page.getByText(deliveryOption).click();
       }
    }

    async clickOnNextButton(){
        await this.next_btn.click()
    }


}