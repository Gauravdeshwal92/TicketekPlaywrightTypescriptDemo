import {Page, Locator,expect} from '@playwright/test'


export class CheckoutPage{

    page:Page
    yourBasket_txt:Locator
    basketSeatSection:Locator
    deliveryMethodBasket:Locator
    submitPayment_btn:Locator
    enmoreTheatre_tAndC:Locator
    espload_tAndC:Locator
    

    constructor(page:Page){
        this.page=page
        this.yourBasket_txt=page.getByRole('heading',{name:'Your basket'});
        this.basketSeatSection = page.locator('.basket_seat_section')
        this.deliveryMethodBasket=page.getByLabel('Delivery Method')
        this.submitPayment_btn=page.locator('.submitPayment')
        this.enmoreTheatre_tAndC=page.getByRole('checkbox',{name:'Enmore Theatre'})
        this.espload_tAndC=page.getByRole('checkbox',{name:'ESPLOAD'})



    }


    async noOfItemsInBasket(category1:string){

        await expect(this.basketSeatSection.filter({hasText:category1}).first()).toBeVisible({timeout:40000});
        const noOfTicket = await this.basketSeatSection.filter({hasText:category1}).count()
        return noOfTicket
    }

    async deliveryMethodInBasket(){
        const deliveryMethod=await this.deliveryMethodBasket.textContent()
        return deliveryMethod

    }

    async submitPayment(){
        await this.submitPayment_btn.click()
    }

    async selectTermsAndCondition(){
        await this.enmoreTheatre_tAndC.check()
        await this.espload_tAndC.check()
    }


}