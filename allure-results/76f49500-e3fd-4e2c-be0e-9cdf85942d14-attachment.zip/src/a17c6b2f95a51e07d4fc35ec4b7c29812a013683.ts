import { test as baseTest, expect, type Cookie, type Page } from '@playwright/test';
import { POManager } from '../pages/POManager';
import { ENV } from '../config/environment';

export type AuthData = {
  token: string;
  cookies: Cookie[];
};

type PageFixtures = {
  pom: POManager;
  auth: AuthData;
};

export const test = baseTest.extend<PageFixtures>({
  auth: async ({ request }, use) => {
    const { email, password } = ENV.credentials;
    if (!email || !password) {
      throw new Error('API login requires username and password to be set in .env');
    }

    const loginResponse = await request.post(ENV.authLoginUrl, {
      data: { email, password },
    });
    if (!loginResponse.ok()) {
      throw new Error(`API login failed with HTTP ${loginResponse.status()}`);
    }

    const responseBody = await loginResponse.json();
    const token = responseBody.token || responseBody.accessToken || '';

    const storageState = await request.storageState();
    const authCookies = storageState.cookies;

    await use({ token, cookies: authCookies });
  },

  pom: async ({ page }, use) => {
    const pom = new POManager(page);
    await use(pom);
  },

  page: async ({ page }, use) => {
    await page.addLocatorHandler(
      page.getByRole('heading', { name: 'We value your privacy' }),
      async () => {
        await page.getByRole('button', { name: 'Close' }).click();
      }
    );
    await use(page);
  },
});

export { expect } from '@playwright/test';
export { Page } from '@playwright/test';